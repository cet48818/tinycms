<?php
// 公用的方法
function show($status, $message, $data=Array()) {
    $result = array(
        'status' => $status,
        'message' => $message,
        'data' => $data
        );
        
        exit(json_encode($result));
}