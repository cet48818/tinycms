<?php
return array(
	//'配置项'=>'配置值'

    //URL地址不区分大小写
    'URL_CASE_INSENSITIVE' =>true,
    'URL_MODEL'=>0,
    'LOAD_EXT_CONFIG' => 'db', // 在config文件夹下建立额外的db配置文件; 如果有多个文件用逗号隔开
);